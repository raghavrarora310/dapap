Udacity Nanodegree Blockchain Developer

Project 5

Dirk Podolak




Network:                        Rinkeby

Contract:                       0x0CD079fb141e810bC1bb1adB74334968e9d5018c

contract creation transaction:  0xdfdc34699c65b186e688ede0461c454807437bdfa5ffe3b6655a9d97fb658371

createStar Transaction:         0x9b6b6e541447504c0c850d270ba138295db9a7b269bc5aba6ef7ba074aa1f6eb

star token ID:                  1978

putStarUpForSale Transaction:   0x3f1f1aa429a619e86b254ea281d23406560534e484ff239c6fff58cc22c1d128


